package br.com.alura.Gson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsonApplication.class, args);
	}

}
